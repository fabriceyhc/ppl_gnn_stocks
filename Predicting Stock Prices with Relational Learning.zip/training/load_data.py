import copy
import numpy as np
import os

def load_EOD_data(data_path, market_name, tickers, steps=1):
    eod_data = []
    masks = []
    ground_truth = []
    base_price = []

    loaded_data_path = os.path.join(data_path, market_name)

    # attempt to load old versions to save time...remove later
    try:
        eod_data = np.load(loaded_data_path + '_eod_data.npy')
        masks = np.load(loaded_data_path + '_mask_data.npy')
        ground_truth = np.load(loaded_data_path + '_gt_data.npy')
        base_price = np.load(loaded_data_path + '_price_data.npy')
        return eod_data, masks, ground_truth, base_price
    except:
        pass

    for index, ticker in enumerate(tickers):
        single_EOD = np.genfromtxt(
            os.path.join(data_path, market_name + '_' + ticker + '_1.csv'),
            dtype=np.float32, delimiter=',', skip_header=False
        )
        if market_name == 'NASDAQ':
            # remove the last day since lots of missing data
            single_EOD = single_EOD[:-1, :]
        if index == 0:
            print('single EOD data shape:', single_EOD.shape)
            eod_data = np.zeros([len(tickers), single_EOD.shape[0],
                                 single_EOD.shape[1] - 1], dtype=np.float32)
            masks = np.ones([len(tickers), single_EOD.shape[0]],
                            dtype=np.float32)
            ground_truth = np.zeros([len(tickers), single_EOD.shape[0]],
                                    dtype=np.float32)
            base_price = np.zeros([len(tickers), single_EOD.shape[0]],
                                  dtype=np.float32)
        for row in range(single_EOD.shape[0]):
            if abs(single_EOD[row][-1] + 1234) < 1e-8:
                masks[index][row] = 0.0
            elif row > steps - 1 and abs(single_EOD[row - steps][-1] + 1234) \
                    > 1e-8:
                ground_truth[index][row] = \
                    (single_EOD[row][-1] - single_EOD[row - steps][-1]) / \
                    single_EOD[row - steps][-1]
            for col in range(single_EOD.shape[1]):
                if abs(single_EOD[row][col] + 1234) < 1e-8:
                    single_EOD[row][col] = 1.1
        eod_data[index, :, :] = single_EOD[:, 1:]
        base_price[index, :] = single_EOD[:, -1]

    # save so we don't have to do all this work every time...remove later
    np.save(loaded_data_path + '_eod_data.npy', eod_data)
    np.save(loaded_data_path + '_mask_data.npy', masks)
    np.save(loaded_data_path + '_gt_data.npy', ground_truth)
    np.save(loaded_data_path + '_price_data.npy', base_price)  

    return eod_data, masks, ground_truth, base_price


def load_graph_relation_data(relation_file, lap=False):
    relation_encoding = np.load(relation_file)
    # print('relation encoding shape:', relation_encoding.shape)
    rel_shape = [relation_encoding.shape[0], relation_encoding.shape[1]]
    mask_flags = np.equal(np.zeros(rel_shape, dtype=int),
                          np.sum(relation_encoding, axis=2))
    ajacent = np.where(mask_flags, np.zeros(rel_shape, dtype=float),
                       np.ones(rel_shape, dtype=float))
    degree = np.sum(ajacent, axis=0)
    for i in range(len(degree)):
        degree[i] = 1.0 / degree[i]
    np.sqrt(degree, degree)
    deg_neg_half_power = np.diag(degree)
    if lap:
        return np.identity(ajacent.shape[0], dtype=float) - np.dot(
            np.dot(deg_neg_half_power, ajacent), deg_neg_half_power)
    else:
        return np.dot(np.dot(deg_neg_half_power, ajacent), deg_neg_half_power)


def load_relation_data(relation_file):
    relation_encoding = np.load(relation_file)
    print('relation encoding shape:', relation_encoding.shape)
    rel_shape = [relation_encoding.shape[0], relation_encoding.shape[1]]
    mask_flags = np.equal(np.zeros(rel_shape, dtype=int),
                          np.sum(relation_encoding, axis=2))
    mask = np.where(mask_flags, np.ones(rel_shape) * -1e9, np.zeros(rel_shape))
    return relation_encoding, mask


def build_SFM_data(data_path, market_name, tickers):
    eod_data = []
    for index, ticker in enumerate(tickers):
        single_EOD = np.genfromtxt(
            os.path.join(data_path, market_name + '_' + ticker + '_1.csv'),
            dtype=np.float32, delimiter=',', skip_header=False
        )
        if index == 0:
            print('single EOD data shape:', single_EOD.shape)
            eod_data = np.zeros([len(tickers), single_EOD.shape[0]],
                                dtype=np.float32)

        for row in range(single_EOD.shape[0]):
            if abs(single_EOD[row][-1] + 1234) < 1e-8:
                # handle missing data
                if row < 3:
                    # eod_data[index, row] = 0.0
                    for i in range(row + 1, single_EOD.shape[0]):
                        if abs(single_EOD[i][-1] + 1234) > 1e-8:
                            eod_data[index][row] = single_EOD[i][-1]
                            # print(index, row, i, eod_data[index][row])
                            break
                else:
                    eod_data[index][row] = np.sum(
                        eod_data[index, row - 3:row]) / 3
                    # print(index, row, eod_data[index][row])
            else:
                eod_data[index][row] = single_EOD[row][-1]
        # print('test point')
    np.save(market_name + '_sfm_data', eod_data)

import torch

def load_corr_timestep(data_path='../data/relation/correlations_trained', market_name='NASDAQ', t=0):
    '''
    Loads the correlational matrix for a given timestep t as a PyTorch tensor

    Keyword arguments:
    data_path   -- string path to the folder containing the numpy correlation matrices
    market_name -- string name of market, options: ['NASDAQ', 'NYSE']
    t           -- int representing the desired timestep
    '''
    file_name = market_name + '_correlation_init_' + str(t) + '.npy'
    load_path = os.path.join(data_path, market_name, file_name)
    return torch.from_numpy(np.load(load_path)).float()

def save_corr_timestep(data, save_path='../data/relation/correlations_trained', market_name='NASDAQ', t=0):
    '''
    Saves the correlational matrix for a given timestep t as an .npy file
    **NOTE: Intended to store tensors after gradient adjustment.**

    Keyword arguments:
    data        -- PyTorch tensor to save
    save_path   -- string path to the destination folder of the PyTorch correlation matrices
    market_name -- string name of market, options: ['NASDAQ', 'NYSE']
    t           -- int representing the desired timestep
    '''
    # setup save directory
    save_path = os.path.join(save_path, market_name)
    if not os.path.exists(save_path):
        os.makedirs(save_path)
    save_file_path = os.path.join(save_path, market_name + '_correlation_init_' + str(t) + '.npy')
    np.save(save_file_path, data.detach().cpu().numpy())