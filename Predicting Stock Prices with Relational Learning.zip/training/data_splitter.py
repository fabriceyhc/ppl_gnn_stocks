import numpy as np
import pickle
import os

data_dir = r'C:\Users\Fabrice\Google Drive\data\gnn_stocks'
save_dir = r'C:\Users\Fabrice\Documents\GitHub\ppl_gnn_stocks\data\relation\correlations\NYSE'

data_dir += r'\NYSE_correlation_init.pkl' 

with open(data_dir, "rb") as input_file:
    corr = pickle.load(input_file)

for t, t_corr in enumerate(corr):
    save_path = os.path.join(save_dir, 'NYSE_correlation_init_' + str(t) + '.npy')
    np.save(save_path, t_corr)